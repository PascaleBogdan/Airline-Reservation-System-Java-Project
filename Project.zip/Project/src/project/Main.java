
package project;
import javax.swing.*;
public class Main {

  public static void main(String[] args) {
    JFrame w = new Window();
    w.setSize(1400, 800);
    w.setLocation(400, 200);
    w.setVisible(true);
    w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

}
